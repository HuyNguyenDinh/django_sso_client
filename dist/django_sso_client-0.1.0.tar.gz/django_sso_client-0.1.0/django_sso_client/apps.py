from django.apps import AppConfig


class DjangoAuthlibClientConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_sso_client'
